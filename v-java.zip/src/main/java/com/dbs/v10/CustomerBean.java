package com.dbs.v10;

import java.util.Date;

public class CustomerBean {

	int  cardNumber;
	String fullName;
	Date expiryDate;
	
	public CustomerBean(int cardNumber, String fullName, Date expiryDate) {
		super();
		this.cardNumber = cardNumber;
		this.fullName = fullName;
		this.expiryDate = expiryDate;
	}
	public int getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(int cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	
}
