package com.dbs.v10;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class vService {
	static int cid;
	static List<CustomerBean> customers = new ArrayList<CustomerBean>();

	static {
		customers.add(new CustomerBean(++cid, "Erich",new Date() ));
		customers.add(new CustomerBean(++cid, "Mihir", new Date()));
		customers.add(new CustomerBean(++cid, "Harsh", new Date()));
		customers.add(new CustomerBean(++cid, "Vasantha",new Date() ));
		customers.add(new CustomerBean(++cid, "Monoj",new Date() ));
		
	}
	
}
