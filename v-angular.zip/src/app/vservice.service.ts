import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {Customer} from '../app/model/Customer';
import { Observable } from 'rxjs/Observable';
@Injectable({
  providedIn: 'root'
})

export class VserviceService {

  apiUrl:string = "https://localhost:8080/";
  constructor(private http : HttpClient) { }

  getCustomers() {
    alert("invoking rest service");
    //return this.http.get<string>('http://localhost:8080/hello');
    //return this.http.get<Customer[]>('../assets/sample.json');
     return this.http.get<Customer[]>('http://localhost:8080//v/view-customers');
   }


}
