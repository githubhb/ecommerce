import { Component, OnInit } from '@angular/core';
import {Customer} from '../model/Customer';
import {VserviceService} from '../vservice.service';
import { ColDef, GridApi, ColumnApi } from 'ag-grid-community';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

    ngOnInit() {
      console.log("before method");
      this.vservice.getCustomers().subscribe(
        response => {
          console.log(response);
          this.customers = response;
        }
      )
        
      console.log("after method");
      console.log(this.customers);
  }

  private customers: Customer[];
  private columnDefs: ColDef[];
  
  // gridApi and columnApi
  private api: GridApi;
  private columnApi: ColumnApi;



  constructor(private vservice: VserviceService) { 
    
    this.columnDefs = this.createColumnDefs();
  }

  // one grid initialisation, grap the APIs and auto resize the columns to fit the available space
onGridReady(params): void {
  this.api = params.api;
  this.columnApi = params.columnApi;    
  this.api.sizeColumnsToFit();    
}
  private createColumnDefs() {
    return [
        {headerName: 'Card Number', field: 'cardNumber', filter: true, enableSorting:true, sortable: true},
        {headerName: 'Full Name', field: 'fullName', filter: true, editable:true, sortable: true},
        {headerName: 'expiry date', field: 'expiryDate', filter: true,sortable:true }
      
    ]
}



  //Get all rows
getRowData() {


  var rowData = [];

  this.api.forEachNode(function(node) {
    rowData.push(node.data);
  });
  console.log("Row Data:");
  console.log(rowData);
}


}
