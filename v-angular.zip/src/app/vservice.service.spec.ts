import { TestBed } from '@angular/core/testing';

import { VserviceService } from './vservice.service';

describe('VserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VserviceService = TestBed.get(VserviceService);
    expect(service).toBeTruthy();
  });
});
