export class Customer {

    cardNumber:number;
    fullName: string;
    expiryDate: Date;


    
}
